
const materias = {
  1: [
    { nombre: "Curso introductorio", modulo: "PI", creditos: 2 },
    { nombre: "Comprensión lectora español", modulo: "LM", creditos: 2 },
    { nombre: "Introducción audiovisual", modulo: "LM", creditos: 7 },
    { nombre: "Teoría de la comunicación", modulo: "TC", creditos: 9 },
    { nombre: "Pensamiento social", modulo: "SCP", creditos: 6 },
    { nombre: "Historia contemporánea", modulo: "SCP", creditos: 7 },
    { nombre: "Introducción a la universidad", modulo: "PI", creditos: 4 },
  ],
  2: [
    { nombre: "Discurso, técnica y comunicación", modulo: "LM", creditos: 9 },
    { nombre: "Economía y política", modulo: "SCP", creditos: 7 },
    { nombre: "Metodología de la investigación", modulo: "M", creditos: 8 },
    { nombre: "Introducción a las profesiones", modulo: "PI", creditos: 7 },
  ],
  3: [
    { nombre: "Lengua I", modulo: "LM", creditos: 9 },
    { nombre: "Comunicación sonora", modulo: "LM", creditos: 6 },
    { nombre: "Ontología", modulo: "SCP", creditos: 6 },
    { nombre: "Estadística básica", modulo: "M", creditos: 8 },
  ],
  4: [
    { nombre: "Inglés", modulo: "LM", creditos: 6 },
    { nombre: "Teoría del cine", modulo: "TC", creditos: 8 },
    { nombre: "Diseño y análisis", modulo: "PI", creditos: 8 },
  ],
  5: [
    { nombre: "Lengua II", modulo: "LM", creditos: 9 },
    { nombre: "Semiótica", modulo: "TC", creditos: 8 },
  ],
  6: [],
  7: [
    { nombre: "Seminario trabajo de grado por orientación", modulo: "PI", creditos: 10 },
  ],
  8: [
    { nombre: "Seminario trabajo de grado por orientación", modulo: "PI", creditos: 10 },
  ],
};

const modulos = {
  "LM": { nombre: "Lenguajes y Medios", color: "#fff3f7", total: 58 },
  "TC": { nombre: "Teoría y Análisis de la Comunicación", color: "#ffe0e6", total: 50 },
  "SCP": { nombre: "Sociedad, Cultura y Políticas", color: "#ffccd5", total: 50 },
  "M": { nombre: "Metodología", color: "#deeaff", total: 40 },
  "PI": { nombre: "Profesional - Integral", color: "#e0f7f7", total: 84 },
};

const state = {};

document.addEventListener("DOMContentLoaded", () => {
  const container = document.getElementById("semesters");
  const creditsPanel = document.getElementById("creditsPanel");
  const creditsList = document.getElementById("creditsList");
  const totalCredits = document.getElementById("totalCredits");

  document.getElementById("toggleCredits").onclick = () => {
    creditsPanel.classList.toggle("hidden");
  };

  for (let s = 1; s <= 8; s++) {
    const sem = document.createElement("div");
    sem.className = "semester";
    sem.innerHTML = `<h3>Semestre ${s}</h3>`;

    (materias[s] || []).forEach((mat, idx) => {
      const matDiv = document.createElement("div");
      matDiv.className = "materia";
      matDiv.style.backgroundColor = modulos[mat.modulo].color;
      matDiv.innerHTML = `
        <h4>${mat.nombre}</h4>
        <small>${modulos[mat.modulo].nombre}</small><br/>
        Créditos: ${mat.creditos}<br/>
        <label><input type="checkbox" onchange="updateCredits()" data-modulo="${mat.modulo}" data-creditos="${mat.creditos}"> Aprobada</label>
      `;
      sem.appendChild(matDiv);
    });

    container.appendChild(sem);
  }

  window.updateCredits = () => {
    let total = 0;
    const moduloSum = {};
    for (const key in modulos) moduloSum[key] = 0;

    document.querySelectorAll("input[type='checkbox']").forEach((cb) => {
      if (cb.checked) {
        const cr = parseInt(cb.dataset.creditos);
        const mod = cb.dataset.modulo;
        moduloSum[mod] += cr;
        total += cr;
      }
    });

    creditsList.innerHTML = "";
    for (const key in modulos) {
      const li = document.createElement("li");
      li.textContent = `${modulos[key].nombre}: ${moduloSum[key]}/${modulos[key].total} créditos`;
      creditsList.appendChild(li);
    }

    totalCredits.textContent = total;
  };
});
